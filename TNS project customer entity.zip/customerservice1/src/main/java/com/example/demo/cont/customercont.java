package com.example.demo.cont;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.customer;
import com.example.demo.serv.customerser;
@RestController
public class customercont {
	@Autowired
	customerser service;
	@GetMapping("/customer/{id}")
	public ResponseEntity<customer> getcustomer(@PathVariable int id){
		customer e = service.getcustomer(id);
		if (e!=null)
			return new ResponseEntity<customer>(e,HttpStatus.OK);
		else
			return new  ResponseEntity<customer>(e,HttpStatus.NOT_FOUND);		
	}
	@GetMapping("/customer")
	public List<customer>list()
	{
		return service.getAllcustomer();
	}
	@PostMapping("/customer")
	public void addcustomer(@RequestBody customer e)
	{
		service.addcustomer(e);
	}	
}
