package com.example.demo.serv;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.customer;
import com.example.demo.repo.customerrepo;
@Service
public class customerser implements customerserv {
	@Autowired
	customerrepo rep;
	@Override
	public customer getcustomer(int id) {
		return rep.findById(id).get();
	}
	@Override
	public List<customer> getAllcustomer() {	
		return rep.findAll();
	}
	@Override
	public void addcustomer(customer e) {
		rep.save(e);
	}
}
