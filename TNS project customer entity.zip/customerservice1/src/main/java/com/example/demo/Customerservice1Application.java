package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
@ComponentScan("com.example.demo")
public class Customerservice1Application {

	public static void main(String[] args) {
		SpringApplication.run(Customerservice1Application.class, args);
	}

}
