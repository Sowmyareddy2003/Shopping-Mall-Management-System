package com.example.demo.serv;

import java.util.List;

import com.example.demo.customer;

public interface customerserv {
	public customer getcustomer(int id);
	 public List<customer>getAllcustomer();
	 public void addcustomer(customer e);

}
